
STATION.name = "Chemistry Set"
STATION.description = "A complex set of chemistry equipment, used in the production of medicines."
STATION.model = "models/mosi/fnv/props/workstations/chemistrylab.mdl"
