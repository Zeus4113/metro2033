
STATION.name = "Engineering Bench"
STATION.description = "A work station used for creating weapons and gadgets."
STATION.model = "models/mosi/fnv/props/workstations/reloadingbench.mdl"
