
STATION.name = "Cooking Station"
STATION.description = "A station used for preparing food and drink"
STATION.model = "models/mosi/fnv/props/workstations/campfire06.mdl"
