
STATION.name = "Tailors Table"
STATION.description = "A sturdy work bench used to create clothing and equipment."
STATION.model = "models/mosi/fnv/props/workstations/workbench.mdl"
