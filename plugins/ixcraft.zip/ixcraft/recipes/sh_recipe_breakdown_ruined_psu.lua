RECIPE.name = "Break Down Ruined PSU"
RECIPE.description = "Salvage useful materials from Ruined PSU."
RECIPE.model = "models/illusion/eftcontainers/powersupplyunit.mdl"
RECIPE.category = "Junk"

RECIPE.requirements = {
    ["ruined_psu"] = 1
}

RECIPE.results = {
	["electronics"] = 2,
}

RECIPE.tools = {
	"steel_wrench",
}

RECIPE.skillIncrease = 0.3

RECIPE.skills = {
    ["Engineering"] = 0,
}


RECIPE:PostHook("OnCanCraft", function(recipeTable, client)

    if not client or not client:GetCharacter() then return false end

    local nearStation = false

    for _, v in pairs(ents.FindByClass("ix_station_engineering_bench")) do
        if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
            nearStation = true
        end
    end

    if not nearStation then return false, "You need to be near a engineering bench." end

    local inv = client:GetCharacter():GetInventory()

    if(recipeTable.tools) then
        local index = 0

        for _, k in pairs(recipeTable.tools) do
            if inv:HasItem(k) then 
                index = index + 1
            end
        end

        if index == table.Count(recipeTable.tools) then
            return true
        end

        return false, "You lack the required tools."
    end

    return true
end)

RECIPE:PostHook("OnCanSee", function(recipeTable, client)
    if not client then return end

    local char = client:GetCharacter()
    if not char then return end

    local hasSkills = false

    if(recipeTable.skills)then    
        local index = 0

        for v, k in pairs(recipeTable.skills) do
            if char:GetAttribute(string.lower(v)) >= k then
                index = index + 1
            end
        end

        if index == table.Count(recipeTable.skills) then
            hasSkills = true
        end
    else
        hasSkills = true
    end

    if hasSkills then
        return true
    end

    return false

end)

RECIPE:PostHook("OnCraft", function(recipeTable, client)
    if not client then return end

    local char = client:GetCharacter()
    if not char then return end

    if recipeTable.skills then 
        for v, k in pairs(recipeTable.skills) do
            char:SetAttrib(string.lower(v) ,char:GetAttribute(string.lower(v)) + recipeTable.skillIncrease)
        end
    end

end)