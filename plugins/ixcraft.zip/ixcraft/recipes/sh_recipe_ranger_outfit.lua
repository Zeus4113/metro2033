RECIPE.name = "Craft Ranger Outfit"
RECIPE.description = "A hardened combat suit crafted using stronger ballistic materials, typically worn by experienced stalkers."
RECIPE.model = "models/devcon/mrp/act/player/ranger_2.mdl"
RECIPE.category = "Outfit"

RECIPE.requirements = {
	["leather"] = 3,
	["kevlar_weave"] = 3,
	["ballistic_plate"] = 1,
}

RECIPE.results = {
    ["outfit_ranger"] = 1
}


RECIPE.skillIncrease = 2

RECIPE.skills = {
    ["Tailoring"] = 12,
}


RECIPE:PostHook("OnCanCraft", function(recipeTable, client)

    if not client or not client:GetCharacter() then return false end

    local nearStation = false

    for _, v in pairs(ents.FindByClass("ix_station_tailors_table")) do
        if (client:GetPos():DistToSqr(v:GetPos()) < 100 * 100) then
            nearStation = true
        end
    end

    if not nearStation then return false, "You need to be near a tailoring table." end

    local inv = client:GetCharacter():GetInventory()

    if(recipeTable.tools) then
        local index = 0

        for _, k in pairs(recipeTable.tools) do
            if inv:HasItem(k) then 
                index = index + 1
            end
        end

        if index == table.Count(recipeTable.tools) then
            return true
        end

        return false, "You lack the required tools."
    end

    return true
end)

RECIPE:PostHook("OnCanSee", function(recipeTable, client)
    if not client then return end

    local char = client:GetCharacter()
    if not char then return end

    local hasSkills = false

    if(recipeTable.skills)then    
        local index = 0

        for v, k in pairs(recipeTable.skills) do
            if char:GetAttribute(string.lower(v)) >= k then
                index = index + 1
            end
        end

        if index == table.Count(recipeTable.skills) then
            hasSkills = true
        end
    else
        hasSkills = true
    end

    if hasSkills then
        return true
    end

    return false

end)

RECIPE:PostHook("OnCraft", function(recipeTable, client)
    if not client then return end

    local char = client:GetCharacter()
    if not char then return end

    if recipeTable.skills then 
        for v, k in pairs(recipeTable.skills) do
            char:SetAttrib(string.lower(v) ,char:GetAttribute(string.lower(v)) + recipeTable.skillIncrease)
        end
    end

end)