if not CLIENT then return end

local staminaThreshold = ix.config.Get("staminaThreshold", 50)
local healthThreshold = ix.config.Get("healthThreshold", 50)

--------------------------------------------------------
-- RADIATION STATE
--------------------------------------------------------

local smoothRadiation = 0
local staticMat = Material("effects/combine_binocoverlay")

--------------------------------------------------------
-- STAMINA SWAY
--------------------------------------------------------

hook.Add("CalcView", "Metro_LowStaminaSway", function(ply, origin, angles, fov)

    local stamina = ply:GetLocalVar("stm", 100)
    if stamina >= staminaThreshold then return end

    local intensity = 1 - (stamina / staminaThreshold)

    angles.roll = angles.roll + math.sin(CurTime() * 2) * intensity * 1.5
    angles.pitch = angles.pitch + math.sin(CurTime() * 1.5) * intensity * 1

    return {
        origin = origin,
        angles = angles,
        fov = fov
    }

end)

--------------------------------------------------------
-- RADIATION SWAY
--------------------------------------------------------

hook.Add("CalcView", "Metro_RadiationSway", function(ply, origin, angles, fov)

    local char = ply:GetCharacter()
    if not char then return end

    local rad = smoothRadiation
    if rad <= 300 then return end

    local sway = math.Clamp((rad - 300) / 200, 0, 1)

    angles.roll = angles.roll + math.sin(CurTime() * 1.5) * sway * 0.8
    angles.pitch = angles.pitch + math.sin(CurTime() * 1.2) * sway * 0.4

    return {
        origin = origin,
        angles = angles,
        fov = fov
    }

end)

--------------------------------------------------------
-- LOW HEALTH DESATURATION
--------------------------------------------------------

function PLUGIN:ApplyLowHealthDesaturation(client)

    local health = client:Health()

    if health >= healthThreshold then return end

    local frac = math.Clamp(health / healthThreshold, 0, 1)

    local intensity = 1 - (frac * frac)

    local maxDesat = 0.65
    local colourAmount = 1 - (intensity * maxDesat)

    DrawColorModify({
        ["$pp_colour_addr"] = 0,
        ["$pp_colour_addg"] = 0,
        ["$pp_colour_addb"] = 0,
        ["$pp_colour_brightness"] = 0,
        ["$pp_colour_contrast"] = 1,
        ["$pp_colour_colour"] = colourAmount,
        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0
    })

end

--------------------------------------------------------
-- RADIATION VISUAL EFFECTS
--------------------------------------------------------

local nextCough = 0

function PLUGIN:ApplyRadiationEffects(client)

    local char = client:GetCharacter()
    if not char then return end

    local rad = char:GetRadiation()
    if rad <= 75 then return end

    local maxRad = 500
    local effectStart = 75

    local frac = math.Clamp((rad - effectStart) / (maxRad - effectStart), 0, 1)

    ----------------------------------------------------
    -- GREEN / YELLOW RADIATION TINT
    ----------------------------------------------------

    local yellow = frac * 0.05
    local green = frac * 0.07

    DrawColorModify({
        ["$pp_colour_addr"] = yellow,
        ["$pp_colour_addg"] = green,
        ["$pp_colour_addb"] = 0,

        ["$pp_colour_brightness"] = -frac * 0.03,
        ["$pp_colour_contrast"] = 1 - frac * 0.08,
        ["$pp_colour_colour"] = 1 - frac * 0.12,

        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0
    })

    ----------------------------------------------------
    -- MOTION BLUR
    ----------------------------------------------------

    if rad > 225 then

        local blurFrac = math.Clamp((rad - 225) / 275, 0, 1)

        DrawMotionBlur(
            0.02,
            blurFrac * 0.4,
            0.01
        )

    end

    ----------------------------------------------------
    -- COUGHING
    ----------------------------------------------------

    if rad > 300 and CurTime() > nextCough then

        local coughRate = math.Clamp((rad - 300) / 200, 0, 1)

        nextCough = CurTime() + Lerp(coughRate, 10, 3)

        client:EmitSound(
            "ambient/voices/cough"..math.random(1,4)..".wav",
            40,
            math.random(95,105),
            0.6
        )

    end

end