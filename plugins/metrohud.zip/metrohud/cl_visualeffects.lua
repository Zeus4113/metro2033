if not CLIENT then return end

local staminaThreshold = ix.config.Get("staminaThreshold", 50)
local healthThreshold = ix.config.Get("healthThreshold", 50)

--------------------------------------------------------
-- RADIATION STATE
--------------------------------------------------------

local smoothRadiation = 0
local staticMat = Material("effects/combine_binocoverlay")

--------------------------------------------------------
-- STAMINA SWAY
--------------------------------------------------------

hook.Add("CalcView", "Metro_LowStaminaSway", function(ply, origin, angles, fov)

    local stamina = ply:GetLocalVar("stm", 100)
    if stamina >= staminaThreshold then return end

    local intensity = 1 - (stamina / staminaThreshold)

    angles.roll = angles.roll + math.sin(CurTime() * 2) * intensity * 1.5
    angles.pitch = angles.pitch + math.sin(CurTime() * 1.5) * intensity * 1

    return {
        origin = origin,
        angles = angles,
        fov = fov
    }

end)

--------------------------------------------------------
-- RADIATION SWAY
--------------------------------------------------------

hook.Add("CalcView", "Metro_RadiationSway", function(ply, origin, angles, fov)

    local char = ply:GetCharacter()
    if not char then return end

    local rad = smoothRadiation
    if rad <= 300 then return end

    local sway = math.Clamp((rad - 300) / 200, 0, 1)

    angles.roll = angles.roll + math.sin(CurTime() * 1.5) * sway * 0.8
    angles.pitch = angles.pitch + math.sin(CurTime() * 1.2) * sway * 0.4

    return {
        origin = origin,
        angles = angles,
        fov = fov
    }

end)

--------------------------------------------------------
-- LOW HEALTH DESATURATION
--------------------------------------------------------

function PLUGIN:ApplyLowHealthDesaturation(client)

    local health = client:Health()

    if health >= healthThreshold then return end

    local frac = math.Clamp(health / healthThreshold, 0, 1)

    local intensity = 1 - (frac * frac)

    local maxDesat = 0.65
    local colourAmount = 1 - (intensity * maxDesat)

    DrawColorModify({
        ["$pp_colour_addr"] = 0,
        ["$pp_colour_addg"] = 0,
        ["$pp_colour_addb"] = 0,
        ["$pp_colour_brightness"] = 0,
        ["$pp_colour_contrast"] = 1,
        ["$pp_colour_colour"] = colourAmount,
        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0
    })

end

--------------------------------------------------------
-- RADIATION VISUAL EFFECTS
--------------------------------------------------------

function PLUGIN:ApplyRadiationEffects(client)

    local char = client:GetCharacter()
    if not char then return end

    local rad = smoothRadiation
    if rad <= 150 then return end

    local maxRad = 500
    local effectStart = 150

    local frac = math.Clamp((rad - effectStart) / (maxRad - effectStart), 0, 1)

    ----------------------------------------------------
    -- COLOUR SHIFT (very subtle)
    ----------------------------------------------------

    local greenShift = frac * 0.02

    DrawColorModify({
        ["$pp_colour_addr"] = 0,
        ["$pp_colour_addg"] = greenShift,
        ["$pp_colour_addb"] = 0,

        ["$pp_colour_brightness"] = 0,
        ["$pp_colour_contrast"] = 1 - frac * 0.04,
        ["$pp_colour_colour"] = 1 - frac * 0.06,

        ["$pp_colour_mulr"] = 0,
        ["$pp_colour_mulg"] = 0,
        ["$pp_colour_mulb"] = 0
    })

    ----------------------------------------------------
    -- STATIC (only when radiation is high)
    ----------------------------------------------------

    if frac > 0.4 then

        local strength = (frac - 0.4) / 0.6

        surface.SetMaterial(staticMat)
        surface.SetDrawColor(255,255,255, strength * 8)

        surface.DrawTexturedRect(0,0,ScrW(),ScrH())

    end

    ----------------------------------------------------
    -- MOTION BLUR (danger zone)
    ----------------------------------------------------

    if rad > 350 then

        local dangerFrac = math.Clamp((rad - 350) / 150, 0, 1)

        DrawMotionBlur(0.03, dangerFrac * 0.2, 0.01)

    end

end